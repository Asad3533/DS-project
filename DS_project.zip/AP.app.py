import pickle
import streamlit as st
from streamlit_option_menu import option_menu

# Load models
@st.cache_resource
def load_model(file_path):
    try:
        with open(file_path, 'rb') as file:
            model = pickle.load(file)
        return model
    except FileNotFoundError:
        st.error(f"File not found: {file_path}")
        return None
    except pickle.UnpicklingError as e:
        st.error(f"Error loading model from {file_path}: {e}")
        return None
    except Exception as e:
        st.error(f"An unexpected error occurred: {e}")
        return None

# Load diabetes and kidney models
diabetes_model = load_model('diabetes_model.pkl')
kidney_model = load_model('kidney_model.pkl')

# Streamlit UI
st.set_page_config(page_title="Health Prediction Models", page_icon="🩺", layout="wide")
st.title("Health Prediction Models")
st.write("Use this application to predict diabetes or kidney disease based on health parameters.")

# Sidebar navigation
with st.sidebar:
    selected_tab = option_menu(
        "Prediction Menu",
        ["Diabetes Prediction", "Kidney Disease Prediction"],
        icons=["activity", "droplet"],
        menu_icon="stethoscope",
        default_index=0
    )

# Diabetes Prediction
if selected_tab == "Diabetes Prediction":
    st.header("Diabetes Prediction")

    if diabetes_model:
        st.write("Enter the following health parameters:")

        # Input fields for diabetes model
        high_bp = st.selectbox("High Blood Pressure (0: No, 1: Yes)", [0, 1])
        high_chol = st.selectbox("High Cholesterol (0: No, 1: Yes)", [0, 1])
        chol_check = st.selectbox("Cholesterol Check (0: No, 1: Yes)", [0, 1])
        bmi = st.number_input("BMI", min_value=0.0, step=0.1)
        smoker = st.selectbox("Smoker (0: No, 1: Yes)", [0, 1])
        stroke = st.selectbox("Stroke History (0: No, 1: Yes)", [0, 1])
        heart_disease = st.selectbox("Heart Disease or Attack (0: No, 1: Yes)", [0, 1])
        physical_activity = st.selectbox("Physical Activity (0: No, 1: Yes)", [0, 1])
        heavy_alcohol = st.selectbox("Heavy Alcohol Consumption (0: No, 1: Yes)", [0, 1])
        healthcare = st.selectbox("Has Healthcare Coverage (0: No, 1: Yes)", [0, 1])
        cost_barrier = st.selectbox("Cost Barrier to Doctor Visit (0: No, 1: Yes)", [0, 1])
        general_health = st.slider("General Health (1: Excellent, 5: Poor)", 1, 5)
        mental_health = st.number_input("Days of Poor Mental Health (0-30)", min_value=0, max_value=30, step=1)
        physical_health = st.number_input("Days of Poor Physical Health (0-30)", min_value=0, max_value=30, step=1)
        difficulty_walking = st.selectbox("Difficulty Walking (0: No, 1: Yes)", [0, 1])
        sex = st.selectbox("Sex (0: Female, 1: Male)", [0, 1])
        age = st.slider("Age Category (1: 18-24, 13: 80+)", 1, 13)

        if st.button("Predict Diabetes", key="diabetes_predict"):
            try:
                input_data = [[
                    high_bp, high_chol, chol_check, bmi, smoker, stroke,
                    heart_disease, physical_activity, heavy_alcohol, healthcare,
                    cost_barrier, general_health, mental_health, physical_health,
                    difficulty_walking, sex, age
                ]]
                prediction = diabetes_model.predict(input_data)[0]
                confidence = diabetes_model.predict_proba(input_data)[0][prediction]

                result = "Positive" if prediction == 1 else "Negative"
                st.success(f"Diabetes Prediction: {result}")
                st.info(f"Confidence Level: {confidence * 100:.2f}%")
            except Exception as e:
                st.error(f"Prediction error: {e}")

# Kidney Disease Prediction
if selected_tab == "Kidney Disease Prediction":
    st.header("Kidney Disease Prediction")

    if kidney_model:
        st.write("Enter the following health parameters:")

        # Input fields for kidney model
        age = st.number_input("Age", min_value=0, step=1)
        bp = st.number_input("Blood Pressure", min_value=0, step=1)
        sg = st.selectbox("Specific Gravity", [1.005, 1.010, 1.015, 1.020, 1.025])
        al = st.number_input("Albumin", min_value=0, step=1)
        su = st.number_input("Sugar", min_value=0, step=1)
        
        rbc = st.selectbox("Red Blood Cells", ["normal", "abnormal"], index=0)
        rbc = 1 if rbc == "abnormal" else 0

        pc = st.selectbox("Pus Cell", ["normal", "abnormal"], index=0)
        pc = 1 if pc == "abnormal" else 0

        pcc = st.selectbox("Pus Cell Clumps", ["notpresent", "present"], index=0)
        pcc = 1 if pcc == "present" else 0

        ba = st.selectbox("Bacteria", ["notpresent", "present"], index=0)
        ba = 1 if ba == "present" else 0

        bgr = st.number_input("Blood Glucose Random", min_value=0, step=1)
        bu = st.number_input("Blood Urea", min_value=0, step=1)
        sc = st.number_input("Serum Creatinine", min_value=0.0, step=0.1)
        sod = st.number_input("Sodium", min_value=0.0, step=0.1)
        pot = st.number_input("Potassium", min_value=0.0, step=0.1)
        hemo = st.number_input("Hemoglobin", min_value=0.0, step=0.1)
        pcv = st.number_input("Packed Cell Volume", min_value=0, step=1)
        wc = st.number_input("White Blood Cell Count", min_value=0, step=1)
        rc = st.number_input("Red Blood Cell Count", min_value=0.0, step=0.1)

        htn = st.selectbox("Hypertension (no/yes)", ["no", "yes"], index=0)
        htn = 1 if htn == "yes" else 0

        dm = st.selectbox("Diabetes Mellitus (no/yes)", ["no", "yes"], index=0)
        dm = 1 if dm == "yes" else 0

        cad = st.selectbox("Coronary Artery Disease (no/yes)", ["no", "yes"], index=0)
        cad = 1 if cad == "yes" else 0

        appet = st.selectbox("Appetite (good/poor)", ["good", "poor"], index=0)
        appet = 1 if appet == "poor" else 0

        pe = st.selectbox("Pedal Edema (no/yes)", ["no", "yes"], index=0)
        pe = 1 if pe == "yes" else 0

        ane = st.selectbox("Anemia (no/yes)", ["no", "yes"], index=0)
        ane = 1 if ane == "yes" else 0

        if st.button("Predict Kidney Disease", key="kidney_predict"):
            try:
                input_data = [[
                    age, bp, sg, al, su, rbc, pc, pcc, ba, bgr, bu, sc,
                    sod, pot, hemo, pcv, wc, rc, htn, dm, cad, appet, pe, ane
                ]]
                prediction = kidney_model.predict(input_data)[0]
                confidence = kidney_model.predict_proba(input_data)[0][prediction]

                result = "Positive" if prediction == 1 else "Negative"
                st.success(f"Kidney Disease Prediction: {result}")
                st.info(f"Confidence Level: {confidence * 100:.2f}%")
            except Exception as e:
                st.error(f"Prediction error: {e}")
